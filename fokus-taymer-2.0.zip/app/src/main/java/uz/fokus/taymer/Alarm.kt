package uz.fokus.taymer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator

// Kanal ID yangilandi: Android kanal ovozini keyin o'zgartirishga ruxsat bermaydi.
const val CHANNEL_ID = "fokus_alarm2"
const val NOTIF_ID = 1001

val VIBRATION_PATTERN = longArrayOf(0, 600, 300, 600, 300, 600)

fun alarmUri(): Uri {
    val a: Uri? = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
    if (a != null) return a
    return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
}

fun alarmAttrs(): AudioAttributes =
    AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()

fun createChannel(ctx: Context) {
    val ch = NotificationChannel(CHANNEL_ID, "Taymer signali", NotificationManager.IMPORTANCE_HIGH)
    ch.setSound(alarmUri(), alarmAttrs())
    ch.enableVibration(true)
    ch.vibrationPattern = VIBRATION_PATTERN
    ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
}

fun alarmIntent(ctx: Context, title: String, text: String): PendingIntent {
    val i = Intent(ctx, AlarmReceiver::class.java)
    i.putExtra("title", title)
    i.putExtra("text", text)
    return PendingIntent.getBroadcast(
        ctx, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )
}

/** Ilova ochiq paytida signal: budilnik ovozi (alarm ovoz balandligida) + tebranish. */
object Ringer {
    private var mp: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val stopper = Runnable { stop() }

    fun start(ctx: Context) {
        stop()
        try {
            val p = MediaPlayer()
            p.setAudioAttributes(alarmAttrs())
            p.setDataSource(ctx.applicationContext, alarmUri())
            p.isLooping = true
            p.prepare()
            p.start()
            mp = p
            handler.postDelayed(stopper, 8000)
        } catch (e: Exception) {
            mp = null
        }
        vibrateNow(ctx)
    }

    fun stop() {
        handler.removeCallbacks(stopper)
        val p = mp
        mp = null
        if (p != null) {
            try { p.stop() } catch (e: Exception) { }
            try { p.release() } catch (e: Exception) { }
        }
    }

    @Suppress("DEPRECATION")
    private fun vibrateNow(ctx: Context) {
        try {
            val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(VIBRATION_PATTERN, -1))
        } catch (e: Exception) { }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        createChannel(ctx)
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(intent.getStringExtra("title") ?: "Fokus Taymer")
            .setContentText(intent.getStringExtra("text") ?: "")
            .setCategory(Notification.CATEGORY_ALARM)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(NOTIF_ID, n)
    }
}
