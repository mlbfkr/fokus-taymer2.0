package uz.fokus.taymer

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var web: WebView
    private val bg: ExecutorService = Executors.newSingleThreadExecutor()

    private var immersiveOn = false
    private var lastScreenOff = 0L
    private var pausedAt = 0L
    private var hideWasScreenOff = false

    private var pendingFile: String? = null

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent != null && intent.action == Intent.ACTION_SCREEN_OFF) {
                lastScreenOff = SystemClock.elapsedRealtime()
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel(this)

        web = WebView(this)
        web.setBackgroundColor(0xFF08090D.toInt())
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.allowContentAccess = false

        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")

        try {
            registerReceiver(screenReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF))
        } catch (e: Exception) {
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun callJs(js: String) {
        runOnUiThread {
            if (!isFinishing && !isDestroyed) web.evaluateJavascript(js, null)
        }
    }

    @Suppress("DEPRECATION")
    private fun applyImmersive(on: Boolean) {
        immersiveOn = on
        window.decorView.systemUiVisibility = if (on) {
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        } else {
            View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && immersiveOn) applyImmersive(true)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // Avval veb-qism (oyna, ichki sahifa, fokus rejimi); hech narsa yopilmasa, ilova orqa fonga o'tadi
        // (taymer to'xtamaydi).
        web.evaluateJavascript("(window.__nativeBack?window.__nativeBack():false)") { r ->
            if (r != "true") moveTaskToBack(true)
        }
    }

    override fun onPause() {
        super.onPause()
        pausedAt = SystemClock.elapsedRealtime()
        web.evaluateJavascript("window.__nativeHide&&window.__nativeHide()", null)
    }

    override fun onResume() {
        super.onResume()
        // Ekran o'chib qolgani uchun ilova orqaga ketganmi yoki boshqa ilovaga o'tilganmi?
        hideWasScreenOff = pausedAt > 0L && lastScreenOff > 0L && lastScreenOff >= pausedAt - 2000L
        Ringer.stop()
        getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
        web.evaluateJavascript("window.__nativeShow&&window.__nativeShow()", null)
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(screenReceiver)
        } catch (e: Exception) {
        }
        bg.shutdownNow()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = if (data != null) data.data else null

        if (requestCode == REQ_SAVE) {
            val content = pendingFile
            pendingFile = null
            if (resultCode != RESULT_OK || uri == null || content == null) {
                callJs("window.__fileSaved('cancel')")
                return
            }
            bg.execute {
                var ok = false
                try {
                    val os = contentResolver.openOutputStream(uri, "wt")
                    if (os != null) {
                        os.use { it.write(content.toByteArray(Charsets.UTF_8)) }
                        ok = true
                    }
                } catch (e: Exception) {
                    ok = false
                }
                callJs("window.__fileSaved('" + (if (ok) "ok" else "fail") + "')")
            }
        } else if (requestCode == REQ_PICK) {
            if (resultCode != RESULT_OK || uri == null) {
                callJs("window.__filePicked(null,'cancel')")
                return
            }
            bg.execute {
                try {
                    val ins = contentResolver.openInputStream(uri)
                    if (ins == null) {
                        callJs("window.__filePicked(null,'read')")
                    } else {
                        val buf = ByteArrayOutputStream()
                        val chunk = ByteArray(8192)
                        var total = 0
                        var tooBig = false
                        ins.use { s ->
                            while (true) {
                                val n = s.read(chunk)
                                if (n < 0) break
                                total += n
                                if (total > MAX_FILE_BYTES) {
                                    tooBig = true
                                    break
                                }
                                buf.write(chunk, 0, n)
                            }
                        }
                        if (tooBig) {
                            callJs("window.__filePicked(null,'big')")
                        } else {
                            val text = buf.toString("UTF-8")
                            callJs("window.__filePicked(" + JSONObject.quote(text) + ",'')")
                        }
                    }
                } catch (e: Exception) {
                    callJs("window.__filePicked(null,'read')")
                }
            }
        }
    }

    inner class Bridge {

        // ---------------- Taymer signali ----------------

        @JavascriptInterface
        fun schedule(endMillis: Double, title: String, text: String) {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val show = PendingIntent.getActivity(
                this@MainActivity, 0, Intent(this@MainActivity, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setAlarmClock(
                AlarmManager.AlarmClockInfo(endMillis.toLong(), show),
                alarmIntent(this@MainActivity, title, text)
            )
        }

        @JavascriptInterface
        fun cancel() {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(alarmIntent(this@MainActivity, "", ""))
        }

        /**
         * Taymer tugadi (HTML: Android.ring(T.end, sarlavha, matn)).
         * Agar tugash vaqti 3 soniyadan ko'proq oldin bo'lgan bo'lsa (ilova orqada edi),
         * budilnik allaqachon bildirishnoma bilan chalingan: qayta chalmaymiz.
         */
        @JavascriptInterface
        fun ring(endMillis: Double, title: String, text: String) {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(alarmIntent(this@MainActivity, "", ""))
            if (System.currentTimeMillis() - endMillis.toLong() > 3000) return
            runOnUiThread { Ringer.start(this@MainActivity) }
        }

        @JavascriptInterface
        fun stopRing() {
            runOnUiThread {
                Ringer.stop()
                getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
            }
        }

        // ---------------- Ekran ----------------

        @JavascriptInterface
        fun keepScreenOn(on: Boolean) {
            runOnUiThread {
                if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        /** To'liq ekran (immersive) rejim: holat va navigatsiya paneli yashiriladi. */
        @JavascriptInterface
        fun setImmersive(on: Boolean) {
            runOnUiThread { applyImmersive(on) }
        }

        /** Oxirgi marta ilova orqaga ketganda ekran o'chganmi (u holda bu chalg'ish emas). */
        @JavascriptInterface
        fun screenWasOff(): Boolean = hideWasScreenOff

        // ---------------- Ruxsatlar ----------------

        @JavascriptInterface
        fun hasUsageAccess(): Boolean = UsageHelper.hasAccess(this@MainActivity)

        @JavascriptInterface
        fun openUsageSettings() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        }

        @JavascriptInterface
        fun openAccessibilitySettings() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        @JavascriptInterface
        fun openNotificationSettings() {
            runOnUiThread {
                val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                i.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                startActivity(i)
            }
        }

        /** {"notif":bool,"usage":bool,"a11y":bool} */
        @JavascriptInterface
        fun permStatus(): String {
            val o = JSONObject()
            o.put("notif", getSystemService(NotificationManager::class.java).areNotificationsEnabled())
            o.put("usage", UsageHelper.hasAccess(this@MainActivity))
            o.put("a11y", BlockPrefs.isServiceEnabled(this@MainActivity))
            return o.toString()
        }

        // ---------------- Ilovalar sarfi ----------------

        /** Qisqa oraliq uchun: boshqa ilovalarda o'tgan soniyalar va 5 soniyadan uzoq kirishlar soni. */
        @JavascriptInterface
        fun otherAppsSeconds(fromMs: Double, toMs: Double): String {
            if (!UsageHelper.hasAccess(this@MainActivity)) return "{\"secs\":-1,\"n\":0}"
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as android.app.usage.UsageStatsManager
            val ignored = UsageHelper.ignoredPackages(this@MainActivity)
            val to = toMs.toLong()
            val ev = usm.queryEvents(fromMs.toLong(), to)
            val e = android.app.usage.UsageEvents.Event()
            val started = HashMap<String, Long>()
            var total = 0L
            var n = 0

            fun close(st: Long, en: Long) {
                val d = en - st
                if (d > 0) {
                    total += d
                    if (d >= 5000) n++
                }
            }

            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                val pkg: String = e.packageName ?: ""
                if (e.eventType == android.app.usage.UsageEvents.Event.MOVE_TO_FOREGROUND) {
                    if (pkg.isNotEmpty() && !ignored.contains(pkg)) started[pkg] = e.timeStamp
                } else if (e.eventType == android.app.usage.UsageEvents.Event.MOVE_TO_BACKGROUND) {
                    val st = started.remove(pkg)
                    if (st != null) close(st, e.timeStamp)
                } else if (e.eventType == android.app.usage.UsageEvents.Event.SCREEN_NON_INTERACTIVE) {
                    for (st in started.values) close(st, e.timeStamp)
                    started.clear()
                }
            }
            for (st in started.values) close(st, to)
            return "{\"secs\":${total / 1000},\"n\":$n}"
        }

        /** Asinxron: natija window.__usage(satr) orqali keladi. */
        @JavascriptInterface
        fun requestUsage(days: Int) {
            bg.execute {
                val json = try {
                    if (UsageHelper.hasAccess(this@MainActivity)) UsageHelper.usageJson(this@MainActivity, days) else ""
                } catch (e: Exception) {
                    ""
                }
                callJs("window.__usage(" + JSONObject.quote(json) + ")")
            }
        }

        /** Asinxron: window.__apps(satr). */
        @JavascriptInterface
        fun requestApps() {
            bg.execute {
                val json = try {
                    UsageHelper.appsJson(this@MainActivity)
                } catch (e: Exception) {
                    "[]"
                }
                callJs("window.__apps(" + JSONObject.quote(json) + ")")
            }
        }

        /** Asinxron: window.__icon(paket, dataUri). */
        @JavascriptInterface
        fun requestIcon(pkg: String) {
            bg.execute {
                val uri = UsageHelper.iconData(this@MainActivity, pkg)
                callJs("window.__icon(" + JSONObject.quote(pkg) + "," + JSONObject.quote(uri) + ")")
            }
        }

        // ---------------- Ilovalarni bloklash ----------------

        @JavascriptInterface
        fun blockStart(endMillis: Double, pkgsJson: String) {
            val set = HashSet<String>()
            try {
                val arr = JSONArray(pkgsJson)
                for (i in 0 until arr.length()) {
                    val p = arr.optString(i, "")
                    if (p.isNotEmpty()) set.add(p)
                }
            } catch (e: Exception) {
            }
            if (set.isEmpty()) {
                BlockPrefs.stop(this@MainActivity)
            } else {
                BlockPrefs.start(this@MainActivity, endMillis.toLong(), set)
            }
        }

        @JavascriptInterface
        fun blockStop() {
            BlockPrefs.stop(this@MainActivity)
        }

        // ---------------- Fayllar (zaxira / CSV) ----------------

        /** Tizimning "Saqlash" oynasi ochiladi. Natija: window.__fileSaved('ok' | 'fail' | 'cancel'). */
        @JavascriptInterface
        fun saveFile(filename: String, mime: String, content: String) {
            runOnUiThread {
                pendingFile = content
                val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = if (mime.isEmpty()) "application/octet-stream" else mime
                i.putExtra(Intent.EXTRA_TITLE, filename)
                startActivityForResult(i, REQ_SAVE)
            }
        }

        /** Tizimning "Fayl tanlash" oynasi. Natija: window.__filePicked(matn, xato). */
        @JavascriptInterface
        fun pickFile() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "*/*"
                startActivityForResult(i, REQ_PICK)
            }
        }

        @JavascriptInterface
        fun shareText(text: String) {
            runOnUiThread {
                val i = Intent(Intent.ACTION_SEND)
                i.type = "text/plain"
                i.putExtra(Intent.EXTRA_TEXT, text)
                startActivity(Intent.createChooser(i, "Jurnalni yuborish"))
            }
        }
    }

    companion object {
        private const val REQ_SAVE = 4101
        private const val REQ_PICK = 4102
        private const val MAX_FILE_BYTES = 12_000_000
    }
}
