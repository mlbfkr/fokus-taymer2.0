plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Imzolash kaliti kod ichida EMAS: GitHub Secrets / muhit o'zgaruvchilaridan olinadi.
val ksPath: String? = System.getenv("FOKUS_KEYSTORE_PATH")
val hasKeystore: Boolean = ksPath != null && file(ksPath).exists()

android {
    namespace = "uz.fokus.taymer"
    compileSdk = 34

    defaultConfig {
        applicationId = "uz.fokus.taymer"
        minSdk = 26
        targetSdk = 34
        versionCode = 6
        versionName = "2.1"
    }

    signingConfigs {
        if (hasKeystore) {
            create("fokus") {
                storeFile = file(ksPath!!)
                storePassword = System.getenv("FOKUS_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("FOKUS_KEY_ALIAS")
                keyPassword = System.getenv("FOKUS_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (hasKeystore) signingConfig = signingConfigs.getByName("fokus")
        }
        debug {
            // Kalit bo'lsa debug ham o'sha kalit bilan imzolanadi: yangilanishlar bir-birining ustiga o'rnatiladi.
            if (hasKeystore) signingConfig = signingConfigs.getByName("fokus")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
