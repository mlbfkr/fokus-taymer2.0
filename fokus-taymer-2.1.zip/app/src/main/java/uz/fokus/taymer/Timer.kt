package uz.fokus.taymer

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator

const val CH_ALARM_SOUND = "fokus_alarm2"   // tizim ovozli (zaxira yo'li)
const val CH_ALARM_QUIET = "fokus_alarm3"   // ovozni xizmatning o'zi chaladi
const val CH_TIMER = "fokus_timer1"
const val ID_ALARM = 1001
const val ID_TIMER = 2001

const val A_START = "uz.fokus.taymer.START"
const val A_PAUSE = "uz.fokus.taymer.PAUSE"
const val A_RESUME = "uz.fokus.taymer.RESUME"
const val A_STOP = "uz.fokus.taymer.STOP"
const val A_RING = "uz.fokus.taymer.RING"
const val A_STOP_RING = "uz.fokus.taymer.STOP_RING"
const val A_ALARM = "uz.fokus.taymer.ALARM"

val VIBRATION_PATTERN = longArrayOf(0, 600, 300, 600, 300, 600)

fun alarmUri(): Uri {
    val a: Uri? = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
    if (a != null) return a
    return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
}

fun alarmAttrs(): AudioAttributes =
    AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()

fun createChannels(ctx: Context) {
    val nm = ctx.getSystemService(NotificationManager::class.java)
    val a = NotificationChannel(CH_ALARM_SOUND, "Taymer signali", NotificationManager.IMPORTANCE_HIGH)
    a.setSound(alarmUri(), alarmAttrs())
    a.enableVibration(true)
    a.vibrationPattern = VIBRATION_PATTERN
    nm.createNotificationChannel(a)

    val q = NotificationChannel(CH_ALARM_QUIET, "Taymer signali (xizmat)", NotificationManager.IMPORTANCE_HIGH)
    q.setSound(null, null)
    q.enableVibration(false)
    nm.createNotificationChannel(q)

    val t = NotificationChannel(CH_TIMER, "Ishlayotgan taymer", NotificationManager.IMPORTANCE_LOW)
    t.setShowBadge(false)
    t.setSound(null, null)
    nm.createNotificationChannel(t)
}

fun alarmTitle(mode: String): String = if (mode == "focus") "Fokus bo'lagi tugadi" else "Tanaffus tugadi"
fun alarmText(mode: String): String = if (mode == "focus") "Dam oling!" else "Ishga qaytamiz!"

class Snap(
    val sid: String, val mode: String, val running: Boolean, val end: Long,
    val left: Long, val total: Long, val title: String, val fired: String
)

/** Taymer holati: ilova yopilsa, qayta yoqilsa ham saqlanadi (SharedPreferences). */
object TimerStore {
    private fun p(c: Context) = c.getSharedPreferences("fokus_timer", Context.MODE_PRIVATE)

    fun read(c: Context): Snap {
        val s = p(c)
        return Snap(
            s.getString("sid", "") ?: "", s.getString("mode", "focus") ?: "focus", s.getBoolean("running", false),
            s.getLong("end", 0L), s.getLong("left", 0L), s.getLong("total", 0L),
            s.getString("title", "Fokus Taymer") ?: "Fokus Taymer", s.getString("fired", "") ?: ""
        )
    }

    fun write(c: Context, sid: String, mode: String, running: Boolean, end: Long, left: Long, total: Long, title: String, fired: String) {
        p(c).edit().putString("sid", sid).putString("mode", mode).putBoolean("running", running)
            .putLong("end", end).putLong("left", left).putLong("total", total)
            .putString("title", title).putString("fired", fired).apply()
    }

    fun clear(c: Context) {
        p(c).edit().putString("sid", "").putBoolean("running", false).putLong("end", 0L).putLong("left", 0L).apply()
    }

    fun markFired(c: Context, sid: String) {
        p(c).edit().putString("fired", sid).putBoolean("running", false).putLong("left", 0L).apply()
    }

    fun setStopReq(c: Context, mode: String, elapsedSec: Long) {
        p(c).edit().putBoolean("stopReq", true).putString("stopMode", mode).putLong("stopElapsed", elapsedSec).apply()
    }

    fun ackStop(c: Context) {
        p(c).edit().putBoolean("stopReq", false).apply()
    }

    fun stopReq(c: Context): Boolean = p(c).getBoolean("stopReq", false)
    fun stopMode(c: Context): String = p(c).getString("stopMode", "focus") ?: "focus"
    fun stopElapsed(c: Context): Long = p(c).getLong("stopElapsed", 0L)
    fun ringing(c: Context): Boolean = p(c).getBoolean("ringing", false)
    fun setRinging(c: Context, v: Boolean) {
        p(c).edit().putBoolean("ringing", v).apply()
    }
}

/** Signal sozlamalari (ilova sozlamalaridan nusxalanadi). */
object AlarmCfg {
    private fun p(c: Context) = c.getSharedPreferences("fokus_alarm", Context.MODE_PRIVATE)
    fun sound(c: Context) = p(c).getBoolean("sound", true)
    fun vib(c: Context) = p(c).getBoolean("vib", true)
    fun repeat(c: Context) = p(c).getBoolean("repeat", true)
    fun set(c: Context, sound: Boolean, vib: Boolean, repeat: Boolean) {
        p(c).edit().putBoolean("sound", sound).putBoolean("vib", vib).putBoolean("repeat", repeat).apply()
    }
}

// ---------------- Budilnik rejalashtirish (har sessiya uchun alohida ID) ----------------

fun alarmPi(c: Context, sid: String, flag: Int): PendingIntent? {
    val i = Intent(c, AlarmReceiver::class.java)
    i.action = A_ALARM
    i.data = Uri.parse("fokus://alarm/" + Uri.encode(sid))
    i.putExtra("sid", sid)
    val code = (sid.hashCode() and 0x3fffffff) + 100
    return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_IMMUTABLE or flag)
}

fun scheduleAlarm(c: Context, sid: String, end: Long) {
    val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val pi = alarmPi(c, sid, PendingIntent.FLAG_UPDATE_CURRENT) ?: return
    val show = PendingIntent.getActivity(
        c, 0, Intent(c, MainActivity::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )
    try {
        // setAlarmClock: Doze rejimida ham aniq ishlaydi va alohida "aniq budilnik" ruxsatini talab qilmaydi.
        am.setAlarmClock(AlarmManager.AlarmClockInfo(end, show), pi)
    } catch (e: SecurityException) {
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi)
            }
        } catch (e2: Exception) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi)
        }
    }
}

fun cancelAlarm(c: Context, sid: String) {
    if (sid.isEmpty()) return
    val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val pi = alarmPi(c, sid, PendingIntent.FLAG_NO_CREATE)
    if (pi != null) {
        am.cancel(pi)
        pi.cancel()
    }
}

fun stopRingingIfAny(c: Context) {
    if (TimerStore.ringing(c)) {
        try {
            c.startService(Intent(c, FocusService::class.java).setAction(A_STOP_RING))
        } catch (e: Exception) {
        }
    }
    c.getSystemService(NotificationManager::class.java).cancel(ID_ALARM)
}

fun openAppIntent(c: Context, alarm: Boolean): PendingIntent {
    val i = Intent(c, MainActivity::class.java)
    i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
    if (alarm) i.putExtra("alarm", true)
    return PendingIntent.getActivity(c, if (alarm) 1 else 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
}

fun mmss(ms: Long): String {
    val s = Math.max(0L, (ms + 999) / 1000)
    val m = s / 60
    val r = s % 60
    return (if (m < 10) "0$m" else "$m") + ":" + (if (r < 10) "0$r" else "$r")
}

// ---------------- Xizmat: taymer bildirishnomasi + signal ----------------

class FocusService : Service() {

    private var mp: MediaPlayer? = null
    private var wl: PowerManager.WakeLock? = null
    private val h = Handler(Looper.getMainLooper())
    private val autoStop = Runnable { stopRinging() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannels(this)
        val a = if (intent != null && intent.action != null) intent.action else A_START
        when (a) {
            A_PAUSE -> pauseTimer()
            A_RESUME -> resumeTimer()
            A_STOP -> stopTimer()
            A_RING -> ring(intent != null && intent.getBooleanExtra("test", false))
            A_STOP_RING -> {
                stopRinging()
            }
            else -> {
                if (TimerStore.ringing(this)) stopRinging(false)
                showTimer()
            }
        }
        return START_NOT_STICKY
    }

    private fun fg(id: Int, n: Notification) {
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(id, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(id, n)
        } catch (e: Exception) {
            getSystemService(NotificationManager::class.java).notify(id, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun action(label: String, a: String, code: Int): Notification.Action {
        val pi = PendingIntent.getService(
            this, code, Intent(this, FocusService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Action.Builder(null as android.graphics.drawable.Icon?, label, pi).build()
    }

    private fun buildTimer(s: Snap): Notification {
        val b = Notification.Builder(this, CH_TIMER)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(s.title)
            .setContentIntent(openAppIntent(this, false))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setCategory(Notification.CATEGORY_PROGRESS)
        if (s.running) {
            // Android o'zi sanaydi: bildirishnomani har soniya yangilash shart emas.
            b.setUsesChronometer(true).setChronometerCountDown(true).setWhen(s.end).setShowWhen(true)
            b.setContentText("Qolgan vaqt")
            b.addAction(action("Pauza", A_PAUSE, 11))
        } else {
            b.setShowWhen(false)
            b.setContentText("Pauza · qoldi " + mmss(s.left))
            b.addAction(action("Davom", A_RESUME, 12))
        }
        b.addAction(action("To'xtatish", A_STOP, 13))
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        return b.build()
    }

    private fun showTimer() {
        val s = TimerStore.read(this)
        if (s.sid.isEmpty() || s.fired == s.sid) {
            if (!TimerStore.ringing(this)) {
                stopForeground(Service.STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            return
        }
        fg(ID_TIMER, buildTimer(s))
    }

    private fun pauseTimer() {
        val s = TimerStore.read(this)
        if (s.sid.isEmpty() || !s.running) {
            showTimer()
            return
        }
        val left = Math.max(0L, s.end - System.currentTimeMillis())
        TimerStore.write(this, s.sid, s.mode, false, s.end, left, s.total, s.title, s.fired)
        cancelAlarm(this, s.sid)
        showTimer()
        MainActivity.pushTimer()
    }

    private fun resumeTimer() {
        val s = TimerStore.read(this)
        if (s.sid.isEmpty() || s.running) {
            showTimer()
            return
        }
        val end = System.currentTimeMillis() + s.left
        TimerStore.write(this, s.sid, s.mode, true, end, s.left, s.total, s.title, s.fired)
        scheduleAlarm(this, s.sid, end)
        showTimer()
        MainActivity.pushTimer()
    }

    private fun stopTimer() {
        val s = TimerStore.read(this)
        if (s.sid.isNotEmpty()) {
            val leftMs = if (s.running) Math.max(0L, s.end - System.currentTimeMillis()) else s.left
            TimerStore.setStopReq(this, s.mode, Math.max(0L, (s.total * 1000 - leftMs) / 1000))
            cancelAlarm(this, s.sid)
            TimerStore.clear(this)
        }
        getSystemService(NotificationManager::class.java).cancel(ID_TIMER)
        if (!TimerStore.ringing(this)) {
            stopForeground(Service.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        MainActivity.pushTimer()
    }

    @Suppress("DEPRECATION")
    private fun ring(test: Boolean) {
        val s = TimerStore.read(this)
        var title = "Signalni sinash"
        var text = "Signal shunday eshitiladi"
        if (!test) {
            if (s.sid.isEmpty() || s.fired == s.sid) {
                // Dublikat himoyasi: bu sessiya uchun signal allaqachon chalingan.
                if (!TimerStore.ringing(this)) {
                    stopForeground(Service.STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
                return
            }
            TimerStore.markFired(this, s.sid)
            title = alarmTitle(s.mode)
            text = alarmText(s.mode)
        }
        getSystemService(NotificationManager::class.java).cancel(ID_TIMER)
        val repeat = AlarmCfg.repeat(this)
        val stop = PendingIntent.getService(
            this, 21, Intent(this, FocusService::class.java).setAction(A_STOP_RING),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CH_ALARM_QUIET)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(text)
            .setCategory(Notification.CATEGORY_ALARM)
            .setContentIntent(openAppIntent(this, true))
            .setFullScreenIntent(openAppIntent(this, true), true)
            .setDeleteIntent(stop)
            .setOngoing(repeat)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(action("To'xtatish", A_STOP_RING, 22))
            .build()
        TimerStore.setRinging(this, true)
        fg(ID_ALARM, n)
        startSignal(repeat)
        h.removeCallbacks(autoStop)
        h.postDelayed(autoStop, if (repeat) 10L * 60L * 1000L else 12000L)
    }

    @Suppress("DEPRECATION")
    private fun startSignal(repeat: Boolean) {
        releaseSignal()
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "fokus:alarm")
            wl?.acquire(90000L)
        } catch (e: Exception) {
        }
        if (AlarmCfg.sound(this)) {
            try {
                val p = MediaPlayer()
                p.setAudioAttributes(alarmAttrs())
                p.setDataSource(applicationContext, alarmUri())
                p.isLooping = true
                p.setVolume(1f, 1f)
                p.prepare()
                p.start()
                mp = p
            } catch (e: Exception) {
                mp = null
            }
        }
        if (AlarmCfg.vib(this)) {
            try {
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                v.vibrate(VibrationEffect.createWaveform(VIBRATION_PATTERN, if (repeat) 0 else -1))
            } catch (e: Exception) {
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun releaseSignal() {
        val p = mp
        mp = null
        if (p != null) {
            try { p.stop() } catch (e: Exception) { }
            try { p.release() } catch (e: Exception) { }
        }
        try {
            (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel()
        } catch (e: Exception) {
        }
        try {
            val w = wl
            if (w != null && w.isHeld) w.release()
        } catch (e: Exception) {
        }
        wl = null
    }

    private fun stopRinging(finish: Boolean = true) {
        h.removeCallbacks(autoStop)
        releaseSignal()
        TimerStore.setRinging(this, false)
        getSystemService(NotificationManager::class.java).cancel(ID_ALARM)
        if (finish) {
            stopForeground(Service.STOP_FOREGROUND_REMOVE)
            val s = TimerStore.read(this)
            // Faol taymer bo'lsa bildirishnomasi qayta ko'rsatiladi, aks holda xizmat to'xtaydi.
            if (s.sid.isNotEmpty() && s.fired != s.sid) showTimer() else stopSelf()
        }
    }

    override fun onDestroy() {
        h.removeCallbacks(autoStop)
        releaseSignal()
        TimerStore.setRinging(this, false)
        super.onDestroy()
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val sid = intent.getStringExtra("sid") ?: return
        val s = TimerStore.read(ctx)
        // Eskirgan yoki takroriy signalga qarshi himoya.
        if (s.sid != sid || s.fired == sid) return
        createChannels(ctx)
        try {
            ctx.startForegroundService(Intent(ctx, FocusService::class.java).setAction(A_RING))
        } catch (e: Exception) {
            // Xizmatni fondan ishga tushirib bo'lmadi: tizim ovozli bildirishnoma bilan signal beramiz.
            TimerStore.markFired(ctx, sid)
            val stop = PendingIntent.getService(
                ctx, 21, Intent(ctx, FocusService::class.java).setAction(A_STOP_RING),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(ctx, CH_ALARM_SOUND)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(alarmTitle(s.mode))
                .setContentText(alarmText(s.mode))
                .setCategory(Notification.CATEGORY_ALARM)
                .setContentIntent(openAppIntent(ctx, true))
                .setFullScreenIntent(openAppIntent(ctx, true), true)
                .setAutoCancel(true)
                .setDeleteIntent(stop)
                .build()
            ctx.getSystemService(NotificationManager::class.java).notify(ID_ALARM, n)
        }
    }
}

/** Telefon qayta yoqilganda: budilnik o'chib ketgani uchun faol sessiyani tiklaydi. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val s = TimerStore.read(ctx)
        if (s.sid.isEmpty() || s.fired == s.sid) return
        createChannels(ctx)
        try {
            if (s.running) {
                if (s.end > System.currentTimeMillis()) {
                    scheduleAlarm(ctx, s.sid, s.end)
                    ctx.startForegroundService(Intent(ctx, FocusService::class.java).setAction(A_START))
                } else {
                    ctx.startForegroundService(Intent(ctx, FocusService::class.java).setAction(A_RING))
                }
            } else {
                ctx.startForegroundService(Intent(ctx, FocusService::class.java).setAction(A_START))
            }
        } catch (e: Exception) {
        }
    }
}
