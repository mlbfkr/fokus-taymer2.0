package uz.fokus.taymer

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.VideoView

/**
 * Animatsiyali splash: qora fonda brend videosi, sekin yaqinlashish effekti bilan.
 * Video tugagach (yoki ekran bosilganda) ilova fade bilan ochiladi.
 */
class SplashActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private var done = false
    private var video: VideoView? = null

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        val v = VideoView(this)
        v.scaleX = 0.9f
        v.scaleY = 0.9f
        root.addView(
            v,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER
            )
        )
        setContentView(root)
        video = v

        root.setOnClickListener { goNext() }

        v.setOnPreparedListener { mp ->
            mp.isLooping = false
            mp.setVolume(0f, 0f)
            // Video tayyor bo'lgach: sekin yaqinlashish (kirish fade'i videoning o'zida bor).
            v.animate()
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(4700)
                .setInterpolator(DecelerateInterpolator(1.5f))
                .start()
        }
        v.setOnCompletionListener { goNext() }
        v.setOnErrorListener { _, _, _ ->
            goNext()
            true
        }

        v.setVideoURI(Uri.parse("android.resource://" + packageName + "/" + R.raw.splash))
        v.start()

        // Xavfsizlik: video biror sabab bilan ishlamasa ham ilova ochiladi.
        handler.postDelayed({ goNext() }, 7000)
    }

    @Suppress("DEPRECATION")
    private fun goNext() {
        if (done) return
        done = true
        handler.removeCallbacksAndMessages(null)
        startActivity(Intent(this, MainActivity::class.java))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            video?.stopPlayback()
        } catch (e: Exception) {
        }
        super.onDestroy()
    }
}
