package uz.fokus.taymer

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Fokus vaqtida bloklash holati. Ilova o'chib qayta yoqilsa ham SharedPreferences'dan tiklanadi. */
object BlockPrefs {
    private const val FILE = "fokus_block"

    class State(val active: Boolean, val end: Long, val pkgs: Set<String>)

    fun read(ctx: Context): State {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val set = p.getStringSet("pkgs", null)
        val copy = HashSet<String>()
        if (set != null) copy.addAll(set)
        return State(p.getBoolean("active", false), p.getLong("end", 0L), copy)
    }

    fun start(ctx: Context, end: Long, pkgs: Set<String>) {
        val copy = HashSet<String>(pkgs)
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putBoolean("active", true)
            .putLong("end", end)
            .putStringSet("pkgs", copy)
            .apply()
    }

    fun stop(ctx: Context) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putBoolean("active", false)
            .apply()
    }

    /** Foydalanuvchi "Maxsus imkoniyatlar"da xizmatni yoqqanmi? */
    fun isServiceEnabled(ctx: Context): Boolean {
        val enabled = try {
            Settings.Secure.getInt(ctx.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED)
        } catch (e: Exception) {
            0
        }
        if (enabled != 1) return false
        val list = Settings.Secure.getString(
            ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val cn = ComponentName(ctx, FocusBlockService::class.java)
        val full = cn.flattenToString()
        val short = cn.flattenToShortString()
        for (s in list.split(':')) {
            if (s.equals(full, true) || s.equals(short, true)) return true
        }
        return false
    }
}

/**
 * Faqat foydalanuvchi o'zi yoqqan holda ishlaydi. Ekran mazmuni o'qilmaydi (canRetrieveWindowContent=false),
 * faqat qaysi ilova oldinga chiqqani (paket nomi) ko'riladi va hech qayerga yuborilmaydi.
 */
class FocusBlockService : AccessibilityService() {

    private var lastPkg = ""
    private var lastAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        val st = BlockPrefs.read(this)
        if (!st.active) return
        if (System.currentTimeMillis() >= st.end) {
            BlockPrefs.stop(this)
            return
        }
        if (!st.pkgs.contains(pkg)) return

        val t = SystemClock.elapsedRealtime()
        if (pkg == lastPkg && t - lastAt < 800) return
        lastPkg = pkg
        lastAt = t

        performGlobalAction(GLOBAL_ACTION_HOME)
        try {
            val i = Intent(this, BlockActivity::class.java)
            i.putExtra("pkg", pkg)
            i.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP
            )
            startActivity(i)
        } catch (e: Exception) {
        }
    }

    override fun onInterrupt() {}
}

/** Bloklangan ilova ochilganda ko'rsatiladigan ekran. */
class BlockActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private var timeView: TextView? = null
    private var end = 0L

    private val ticker = object : Runnable {
        override fun run() {
            update()
            handler.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, sp: Float, color: String, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sp
        t.setTextColor(Color.parseColor(color))
        t.gravity = Gravity.CENTER
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun action(text: String, filled: Boolean, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        val bg = GradientDrawable()
        bg.cornerRadius = dp(14).toFloat()
        bg.setColor(Color.parseColor(if (filled) "#4D8DFF" else "#1D2029"))
        b.background = bg
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = intent.getStringExtra("pkg") ?: ""
        val appName = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        end = BlockPrefs.read(this).end

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(Color.parseColor("#08090D"))
        root.setPadding(dp(28), dp(28), dp(28), dp(28))

        root.addView(label("Fokus davom etmoqda", 22f, "#FFFFFF", true))

        val sub = label("\"" + appName + "\" fokus vaqtida bloklangan", 15f, "#A0A5B2", false)
        val subLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        subLp.topMargin = dp(10)
        root.addView(sub, subLp)

        val tv = label("--:--", 56f, "#4D8DFF", true)
        timeView = tv
        val tvLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        tvLp.topMargin = dp(28)
        root.addView(tv, tvLp)

        root.addView(
            label("Qolgan fokus vaqti", 14f, "#A0A5B2", false),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        val b1 = action("Fokusga qaytish", true) {
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(i)
            finish()
        }
        val b1Lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
        b1Lp.topMargin = dp(40)
        root.addView(b1, b1Lp)

        val b2 = action("Bosh ekranga", false) { goHome() }
        val b2Lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
        b2Lp.topMargin = dp(12)
        root.addView(b2, b2Lp)

        setContentView(root)
    }

    private fun goHome() {
        val h = Intent(Intent.ACTION_MAIN)
        h.addCategory(Intent.CATEGORY_HOME)
        h.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(h)
        finish()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        goHome()
    }

    private fun update() {
        val left = (end - System.currentTimeMillis()) / 1000
        if (left <= 0) {
            finish()
            return
        }
        val m = left / 60
        val s = left % 60
        timeView?.text = String.format("%02d:%02d", m, s)
    }

    override fun onResume() {
        super.onResume()
        end = BlockPrefs.read(this).end
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }
}
