package uz.fokus.taymer

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Process
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Ilovalar ro'yxati, ikonkalar va foydalanish vaqti (UsageStatsManager). */
object UsageHelper {

    fun hasAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** Hisobga olinmaydigan paketlar: ilovaning o'zi, tizim interfeysi va bosh ekran (launcher). */
    fun ignoredPackages(ctx: Context): Set<String> {
        val set = HashSet<String>()
        set.add(ctx.packageName)
        set.add("com.android.systemui")
        set.add("android")
        try {
            val home = Intent(Intent.ACTION_MAIN)
            home.addCategory(Intent.CATEGORY_HOME)
            for (ri in ctx.packageManager.queryIntentActivities(home, 0)) {
                set.add(ri.activityInfo.packageName)
            }
        } catch (e: Exception) { }
        return set
    }

    private fun labelOf(pm: PackageManager, pkg: String): String {
        return try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    /** Telefondagi ochiladigan (launcher) ilovalar: [{"p":paket,"n":nom}, ...] */
    fun appsJson(ctx: Context): String {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN)
        i.addCategory(Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        val list = ArrayList<Pair<String, String>>()
        for (ri in pm.queryIntentActivities(i, 0)) {
            val p = ri.activityInfo.packageName
            if (p == ctx.packageName) continue
            if (!seen.add(p)) continue
            list.add(Pair(p, ri.loadLabel(pm).toString()))
        }
        list.sortBy { it.second.lowercase() }
        val arr = JSONArray()
        for (x in list) {
            val o = JSONObject()
            o.put("p", x.first)
            o.put("n", x.second)
            arr.put(o)
        }
        return arr.toString()
    }

    /** Ilova ikonkasi: 64x64 PNG (data URI). Xato bo'lsa bo'sh satr. */
    fun iconData(ctx: Context, pkg: String): String {
        return try {
            val d = ctx.packageManager.getApplicationIcon(pkg)
            val size = 64
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            d.setBounds(0, 0, size, size)
            d.draw(c)
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
            "data:image/png;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            ""
        }
    }

    /**
     * So'nggi `days` kun uchun har kunning ilovalar bo'yicha foydalanish vaqti (soniya).
     * Chiqish: {"days":[{"d":"2026-11-09","t":jami,"a":{"paket":soniya}}], "n":{"paket":"Nom"}}
     */
    fun usageJson(ctx: Context, days: Int): String {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val ignored = ignoredPackages(ctx)
        val n = if (days < 1) 1 else if (days > 14) 14 else days

        // Mahalliy yarim tunlar: starts[i] = i-kunning boshlanishi, starts[n] = ertangi kun boshi.
        val starts = LongArray(n + 1)
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        cal.add(Calendar.DAY_OF_YEAR, -(n - 1))
        for (i in 0..n) {
            starts[i] = cal.timeInMillis
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }

        val now = System.currentTimeMillis()
        val perDay = Array(n) { HashMap<String, Long>() }
        val open = HashMap<String, Long>()

        fun addInterval(pkg: String, st: Long, en: Long) {
            if (en <= st) return
            for (i in 0 until n) {
                val a = if (st > starts[i]) st else starts[i]
                val b = if (en < starts[i + 1]) en else starts[i + 1]
                if (b > a) {
                    val m = perDay[i]
                    val prev = m[pkg] ?: 0L
                    m[pkg] = prev + (b - a)
                }
            }
        }

        val ev = usm.queryEvents(starts[0], now)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            val pkg: String = e.packageName ?: ""
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> {
                    if (pkg.isNotEmpty() && !ignored.contains(pkg)) open[pkg] = e.timeStamp
                }
                UsageEvents.Event.MOVE_TO_BACKGROUND -> {
                    val st = open.remove(pkg)
                    if (st != null) addInterval(pkg, st, e.timeStamp)
                }
                UsageEvents.Event.SCREEN_NON_INTERACTIVE -> {
                    for ((p, st) in open) addInterval(p, st, e.timeStamp)
                    open.clear()
                }
            }
        }
        for ((p, st) in open) addInterval(p, st, now)

        val pm = ctx.packageManager
        val labels = JSONObject()
        val daysArr = JSONArray()
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        for (i in 0 until n) {
            val m = perDay[i]
            var total = 0L
            for (v in m.values) total += v
            val top = m.entries.sortedByDescending { it.value }.take(25)
            val a = JSONObject()
            for (en in top) {
                val secs = en.value / 1000
                if (secs < 5) continue
                a.put(en.key, secs)
                if (!labels.has(en.key)) labels.put(en.key, labelOf(pm, en.key))
            }
            val d = JSONObject()
            d.put("d", fmt.format(Date(starts[i])))
            d.put("t", total / 1000)
            d.put("a", a)
            daysArr.put(d)
        }
        val out = JSONObject()
        out.put("days", daysArr)
        out.put("n", labels)
        return out.toString()
    }
}
